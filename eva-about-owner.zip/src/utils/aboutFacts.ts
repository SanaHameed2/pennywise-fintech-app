/**
 * REAL facts only. Anything left as "" (or [] ) is simply NOT shown on the site.
 * Fill the remaining fields from real information. Do not invent numbers.
 */
export const ABOUT_FACTS = {
  founded: "", // the real year the shop opened
  ownerName: "Hammad H.",
  ownerRole: "", // e.g. "Founder & Lead Technician" (confirm the real role)
  ownerPhoto: "/images/team/owner.webp",
  ownerBio: "", // 2-4 sentences: background, training, why the shop started
  specialities: [] as string[], // e.g. ["iPhone screen and battery repair", "Laptop SSD upgrades"]
  partsPolicy: "", // what parts you use and where they come from
  repairGuarantee: "", // exact repair warranty, matching the /warranty page
};
